from django.contrib import admin
from .models import Services, ContentBox, ProjectDone, Mainmenu , TipsAbout

admin.site.register(Services)
admin.site.register(ContentBox)
admin.site.register(ProjectDone)
admin.site.register(Mainmenu)
admin.site.register(TipsAbout)
